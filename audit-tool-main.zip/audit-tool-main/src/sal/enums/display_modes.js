export const FormDisplayModes = {
  new: "new",
  edit: "edit",
  view: "view",
};

export const FieldDisplayModes = {
  new: "new",
  edit: "edit",
  view: "view",
};
